Running the Python Notebook from start to finish will go through each part. The code first trains and then tests the speaker dependent model and then the speaker independent model.
The confusion matrices and the accuracy for each respective test will print out after their respective section. The results section is written at the end after all the experiments.
